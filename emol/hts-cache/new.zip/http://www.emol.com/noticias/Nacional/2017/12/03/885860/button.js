
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#">
<head prefix="og: http://ogp.me/ns# object: http://ogp.me/ns/object#">
    
<title>Último Minuto | Emol.com</title>
<meta charset="utf-8" />
<meta http-equiv="Content-Type" content="text/html;" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="alexaVerifyID" content="VZ0JZZVEK5tQwbghGEcxKoye0PA" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="title" content="Todas las noticias de Último Minuto | Emol.com | Emol.com"/>
<meta http-equiv="title" content="Todas las noticias de Último Minuto | Emol.com | Emol.com"/>
<meta name="description" content="Todas las noticias de Último Minuto. Entra e informate de los últimos acontecimientos ocurridos en nuestro país en Emol.com" />
<meta name="author" content="El Mercurio S.A.P."/>
<meta name="copyright" content="El Mercurio S.A.P." />
<meta name="Generator" content="Pandora 5.0" />
<meta name="authoring.tool" content="Pandora 5.0" />
<meta name="Keywords" content="EMOL, Noticias, Nacional, Tiempo Libre, E-Commerce, Chat, Servicios, Chile, mercurio, emol,  foros, encuestas, Economia, Negocios, Internacional, Deportes, Sociedad, Cultura, Espectaculo, Internet, Ciencia, Tecnologia, Reportajes, Artes, Literatura, Politica, Finanzas, Empresas, Futbol, Sociedad, Entrevistas, Revista del Campo, zona de contacto, wiken, el sabado, timon, ya, vivienda y decoración, revista del domingo, revista de libros"/>
<meta http-equiv="keywords" content="EMOL, Noticias, Nacional, Tiempo Libre, E-Commerce, Chat, Servicios, Chile, mercurio, emol,  foros, encuestas, Economia, Negocios, Internacional, Deportes, Sociedad, Cultura, Espectaculo, Internet, Ciencia, Tecnologia, Reportajes, Artes, Literatura, Politica, Finanzas, Empresas, Futbol, Sociedad, Entrevistas, Revista del Campo, zona de contacto, wiken, el sabado, timon, ya, vivienda y decoración, revista del domingo, revista de libros"/>
<meta name="Classification" content="General"/>
<meta name="RATING" content="General"/>
<meta name="Distribution" content="Global"/>
<meta name="Language" content="Spanish"/>
<meta name="robots" content="index,follow"/>
<meta name="Revisit-after" content="1 days"/>
<meta http-equiv="Expires" content="0"/> 
<meta http-equiv="Last-Modified" content="0"/> 
<meta http-equiv="Cache-Control" content="no-cache, mustrevalidate"/> 
<meta http-equiv="Pragma" content="no-cache"/>
<meta name="application-name" content="Emol.com"/>
<meta name="msapplication-tooltip" content="Emol.com El sitio de noticias online de Chile"/>
<meta name="msapplication-task" content="name=Facebook - Emol;action-uri=http://www.emol.com/redessociales/facebook.asp?utm_source=winSeven&amp;utm_medium=taskBar;icon-uri=http://www.emol.com/imagenes/iconos/facebook.ico"/>
<meta name="msapplication-task" content="name=Twitter - Emol;action-uri=http://www.emol.com/redessociales/twitter.asp?utm_source=winSeven&amp;utm_medium=taskBar;icon-uri=http://www.emol.com/imagenes/iconos/twitter.ico"/>
<meta name="msapplication-starturl" content="http://www.emol.com?utm_source=winSeven&amp;utm_medium=taskBar"/>
<meta name="msapplication-window" content="width=1000;height=700"/>
<meta name="msapplication-navbutton-color" content="#3291D8"/>
<meta name="DC.title" content="Todas las noticias de Último Minuto | Emol.com | Emol.com"/>
<meta name="DC.author" content="El Mercurio S.A.P."/>
<meta name="DC.description" lang="es" content="Todas las noticias de Último Minuto. Entra e informate de los últimos acontecimientos ocurridos en nuestro país en Emol.com" />
<meta name="DC.creator" content="El Mercurio S.A.P."/>
<meta name="DC.language" SCHEME="RFC1766" content="Spanish"/>
<meta name="DC.format" scheme="IMT" content="text/html" />
<meta name="VW96.objecttype" content="Homepage"/>
<meta name="resource-type" content="Homepage"/>
<meta name="doc-type" content="Homepage"/>
<script src="http://static.emol.cl/emol50/js/AC_RunActiveContent.js" type="text/javascript"></script>

<link rel="shortcut icon" href="http://static.emol.cl/emol50/img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="http://static.emol.cl/emol50/css/font-awesome.min.css?v=1" />
<link href="http://static.emol.cl/emol50/css/estilo.min.css?v=1" rel="stylesheet" type="text/css" />
<link href="http://static.emol.cl/emol50/css/social.min.css?v=8" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://static.emol.cl/emol50/js/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/jquery-ui.min.js"></script>

<script type="text/javascript" src="http://static.emol.cl/emol50/js/contador_comentarios.js?v=1"></script>

<script type="text/javascript" src="http://static.emol.cl/emol50/js/funcionesComun.js?v=7"></script>

<meta name="google-site-verification" content="cynvtj_jE3Eb8Y2AUf4VsbkcDCG8x6EXr809BkpBlr8" />
<!-- Emoltv videos -->
<link href="http://static.emol.cl/emol50/css/video-js.min.css" rel="stylesheet" type="text/css" />
<link href="http://static.emol.cl/emol50/css/videojs-resolution-switcher.css" rel="stylesheet" type="text/css" />
<link href="http://static.emol.cl/emol50/css/videojs.vast.vpaid.min.css" rel="stylesheet" type="text/css" />

<link href="http://static.emol.cl/emol50/css/videojs-panorama.css" rel="stylesheet">
<script type="text/javascript" src="http://static.emol.cl/emol50/js/videojs-ie8.min.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/video.js?v=1"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/videojs-contrib-hls.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/videojs_5.vast.vpaid.js?v=1"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/videojs-resolution-switcher.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/Youtube.js?v=2"></script>

<script type="text/javascript" src="http://static.emol.cl/emol50/js/three.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/videojs-panorama.v5.js"></script>

<!-- Fin Emoltv videos -->
<script type="text/javascript" src="http://static.emol.cl/emol50/js/encuestas.js?v=1"></script>
<script id="navegg" type="text/javascript" src="//tag.navdmp.com/tm42978.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/jquery.gritter.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/notificaciones.js?v=1"></script>

<script type="text/javascript" src="http://static.emol.cl/emol50/js/cajasAjaxPortadillas.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/caja_portada.js"></script>
<link href="http://static.emol.cl/emol50/css/estilo_componentes.min.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
    cajas_portada_lp.init();
</script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/ZoomAD.Mer.js"></script>
    <script type="text/javascript">
        var GlobalHost = "http://static.emol.cl/emol50";
        //var sec = "";
    </script>
    
<script type="text/javascript" language="javascript" src="http://static.emol.cl/emol50/js/publicidadsetup/publicidadNO.js?v=103"></script>

<script type="text/javascript">
    if (typeof (OA_zones) != 'undefined') {
        var OA_zoneids = '';
        for (var zonename in OA_zones) OA_zoneids += escape(zonename + '=' + OA_zones[zonename] + "|");
        OA_zoneids += '&amp;nz=1';
    } else {
        var OA_zoneids = escape('');
    }

    if (typeof (OA_source) == 'undefined') { OA_source = ''; }
    var OA_p = location.protocol == 'https:' ? 'https://rvv.emol.com/www/noticias/sqn.php' : 'http://rvv.emol.com/www/noticias/sqn.php';
    var OA_r = Math.floor(Math.random() * 99999999);
    OA_output = new Array();

    var OA_spc = "<" + "script type='text/javascript' ";
    OA_spc += "src='" + OA_p + "?zones=" + OA_zoneids;
    OA_spc += "&amp;source=" + escape(OA_source) + "&amp;r=" + OA_r;
    OA_spc += "&amp;blockcampaign=1";
    OA_spc += (document.charset ? '&amp;charset=' + document.charset : (document.characterSet ? '&amp;charset=' + document.characterSet : ''));

    if (window.location) OA_spc += "&amp;loc=" + escape(window.location);
    if (document.referrer) OA_spc += "&amp;referer=" + escape(document.referrer);
    OA_spc += "'><" + "/script>";
    document.write(OA_spc);

    function OA_show(name) {
        if (typeof (OA_output[name]) == 'undefined') {
            return;
        } else {
            document.write(OA_output[name]);
        }
    }

    function OA_showpop(name) {
        zones = window.OA_zones ? window.OA_zones : false;
        var zoneid = name;
        if (typeof (window.OA_zones) != 'undefined') {
            if (typeof (zones[name]) == 'undefined') {
                return;
            }
            zoneid = zones[name];
        }

        OA_p = location.protocol == 'https:' ? 'https://rvv.emol.com/www/noticias/apu.php' : 'http://rvv.emol.com/www/noticias/apu.php';

        var OA_pop = "<" + "script type='text/javascript' ";
        OA_pop += "src='" + OA_p + "?zoneid=" + zoneid;
        OA_pop += "&amp;source=" + escape(OA_source) + "&amp;r=" + OA_r;
        OA_spc += "&amp;blockcampaign=1";
        if (window.location) OA_pop += "&amp;loc=" + escape(window.location);
        if (document.referrer) OA_pop += "&amp;referer=" + escape(document.referrer);
        OA_pop += "'><" + "/script>";

        document.write(OA_pop);
    }
</script>
<script type='text/javascript'>
    <!--// <![CDATA[ 
    var zn = [];
    var dm = [];
    var pl = [];
    var az = true;
    function randomString(length, chars) {
        var result = '';
        for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
        return result;
    }
    var rString = randomString(10, '0123456789abcdefghijklmnopqrstuvwxyz');
    var qString = randomString(5, 'abcdefghijklmnopqrstuvwxyz') + "=" + randomString(2, '0123456789');
    // ]]> -->
</script>
    
    <link href="http://static.emol.cl/emol50/css/buscador_2015.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="itt">
        <script type='text/javascript'>
            <!--// <![CDATA[ 
            OA_show('NO_960X680');
            // ]]> -->
        </script>
    </div>
    <div id="contenedor">
        <script type='text/javascript'>
            <!--// <![CDATA[
            OA_show('NO_930X60');
            // ]]> -->
        </script>
    </div>
    <div id="cuTodas_cuHeader_EstiloHeaderPrincipal">
    <div id="menu_corp_cont">  
        <ul>
            <li class="emol"><a class="emol" href="http://www.emol.com">Emol</a></li>
            <li class="emol_white"><a href="http://www.mer.cl">El Mercurio</a></li>
            <li class="emol_white"><a href="http://www.elmercurio.com/blogs">Blogs</a></li>
            <li class="emol_white"><a class="emol" href="http://www.elmercurio.com/legal">Legal</a></li>
            <li class="emol_white"><a href="http://www.elmercurio.com/campo">Campo</a></li>
            <li class="emol_white"><a href="http://www.elmercurio.com/inversiones">Inversiones</a></li>
            <li class="emol_blue"><a href="http://automoviles.emol.com/">Autos</a></li>
            <li class="emol_blue"><a href="http://www.propiedades.emol.com/">Propiedades</a></li>
            <li class="emol_blue"><a href="http://empleos.emol.com">Empleos</a></li>
            <li class="emol_gris">
                <a href="http://www.economicos.cl/">Económicos.cl</a>
                <a href="http://www.economicos.cl/vehiculos">Autos</a>-
                <a href="http://www.economicos.cl/propiedades">Casas</a>
            </li>
            <li class="emol_blue"><a href="http://www.lasegunda.com">La Segunda</a></li>
            <li class="emol_blue"><a href="http://www.lun.com">Lun</a></li>
        </ul>
    </div>
    <div id="header_logo">
        
        <div id="header_izq">            
            <div id="header_logo_pub175x80izq">
		        <script type="text/javascript">
                <!--// <![CDATA[
                    OA_show('POR_OREJA_1');
		        // ]]> -->
		        </script>
	        </div>	
        </div>
        <div id="header_der">
            <div id="header_logo_pub175x80der">
            <script type="text/javascript">
            <!--// <![CDATA[
                OA_show('POR_OREJA_2');
            // ]]> -->
            </script>
            </div>
        </div>      
        <div id="header_central_despliegue">
            <span class="img_emol_des_2015">
                    <a id="cuTodas_cuHeader_linklogo" href="/"><img id="cuTodas_cuHeader_logoEmol" title="Emol.com" title="Emol.com" src="http://static.emol.cl/emol50/img/logo_emol.gif" alt="Emol.com" /></a>
                    <div class="logo_foto_2016"> 
                        <a id="cuTodas_cuHeader_linklogoF"></a>
                    </div>
            </span>
            <span class="tit_emol_des_2015">
	            
            </span>
        </div>
        <div id="cuTodas_cuHeader_cuFechaModificacion_emolfecha" class="emol_fecha">Santiago: Domingo 03 de diciembre del 2017 | Actualizado 14:45</div>
    </div>
    <div id="nav_main">
        <div id="menu_emol_2015">
            <nav>
            <ul id="cuTodas_cuHeader_menu_seccions"><li><a href="/"><img src="http://static.emol.cl/emol50/img/home_emol.png" alt="http://static.emol.cl/emol50emol.com"></img></a></li><li class="nav_activo"><a href="/">Noticias</a></li><li><a href="/economia/">Econom&#237;a</a></li><li><a href="/deportes/">Deportes</a></li><li><a href="/espectaculos/">Espect&#225;culos</a></li><li><a href="/tendencias/">Tendencias</a></li><li><a href="/autos/">Autos</a></li><li><a href="/servicios/">Servicios</a></li><li class="nav_mult"><a href="/fotos/"><img title="Fotos" src="http://static.emol.cl/emol50/img/emolfotos-not.png"></img></a></li><li class="nav_mult"><a href="http://tv.emol.com/"><img title="EmolTV" src="http://static.emol.cl/emol50/img/emoltv-not.png"></img></a></li><li class="nav_mult"><a href="/360/"><img title="360" src="http://static.emol.cl/emol50/img/logo-menu-360.svg"></img></a></li></ul>
        </nav>
        </div>
        <div id="nav_sub">
            <ul id="cuTodas_cuHeader_menu_subSeccion"><li><a href="/nacional/">Chile</a></li><li><a href="/internacional/">Mundo</a></li><li><a href="/tecnologia/">Tecnolog&#237;a</a></li><li><a href="/educacion/">Educaci&#243;n</a></li><li><a href="/documentos/">Documentos</a></li><li><a href="/multimedia/">Multimedia</a></li></ul>
	    </div>
    </div>
    
<script type="text/javascript" src="http://static.emol.cl/emol50/js/webtoolkit.url.js"></script>
<script language="javascript" type="text/javascript">
    /* <![CDATA[ */
    function press_key(e) {
        if (((document.all) ? e.keyCode : e.which) == "13") {
            BuscarGeneral();
        } else {
            $("#frase_busqueda").val($("#frase_busqueda").val() + e.key);
        }
    };
    function BuscarGeneral() {
        var strQUERY;
        var strTipoBusqueda;
        strQUERY = document.getElementById("frase_busqueda").value;
        window.location = "/Buscador/?query=" + Url.encode(strQUERY.toLowerCase());
    }
</script>

<div id="cont_buscador">
    <div class="cont_inputs_buscadores">
        <div id="buscador_home_inputs">
	        <span class="frase_input_bus"><input name="frase_busqueda" id="frase_busqueda" type="text" placeholder="Buscar" onkeypress="press_key(event);return false;" autocomplete="off"/></span>
            <div id="buscador_lupa">
		        <a href="javascript:BuscarGeneral();"><img id="cuTodas_cuHeader_cuBuscador_logoLupa" border="0" src="http://static.emol.cl/emol50/img/icon_lupa_emol_2015.png" alt="Buscar..." /></a>
	        </div>	    
        </div>
        <div class="cont_buscador_amarillas">
		    <span class="cont_input_bus_amarillas">
			    <input type="text" id="queAmarilla" name="queAmarilla" />
		    </span>
		    <span class="cont_bus_amarillas_icon">
                <a href="javascript:buscadorAmarillas();">
			        <img src="http://static.emol.cl/emol50/img/icon_lupa_amarillas_2015.png" width="22" height="22" border="0" />
                </a>
		    </span>
        </div>
    </div>
</div> 
</div>

    <div class="left_e_2015 cont_e_c_2015">
        <div class="cont_736_e_2015">
            
<script type="text/javascript" src="http://static.emol.cl/emol50/js/jquery.lazyload.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/Todas.js"></script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/hammer.min.js"></script>
<script>
	$(function () {
	    if (window.location.pathname.indexOf("movil") > -1) {
	        var red = document.getElementById("contenedor_buscador");
	        Hammer(red).on("swipeleft", function () {
	            Next();
	        });
	        Hammer(red).on("swiperight", function () {
	            Prev();
	        });
	    }
	});

</script>
<div id="contenedor_buscador">
    <div id="contenedor_todas" class="cont_736_e_2015 cont_buscador_mar">
        <div class="cont_tit_sec_emol bg_tit_sec bor_tit_sec"><span class="cont_txt_tit" id="nombreTema"></span></div>        
        <div class="cont_int_secs_2015 cont_int_sec_pad_top bus_noticias">
            <ul id="listNews">
            </ul>
        </div>
        <script>
            ListNews("*", "*");			
        </script>
        <div class="cont_n_pag_busca">
            <div class="pagination-container">
                <nav class="pagination">
                    <ul id="listPages">
                    </ul>
                </nav>
                <nav class="pagination-next-prev">
                    <ul>
                        <li id="li_prev" style="display: none;"><a class="prev current-page-next-prev" href="javascript:Prev();"><i class="fa fa-chevron-left"></i><span class="txt_anterior">Anterior</span></a></li>
                        <li id="li_next" style="display: none;"><a class="next current-page-next-prev" href="javascript:Next();"><span class="txt_siguiente">Siguiente</span> <i class="fa fa-chevron-right"></i></a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>












        </div>
    </div>
    <div class="cont_200_e_2015">
        
<div class="cont_tab_2015_editor cont_se_debate">
    <div class="cont_tab_2015_tit_editor">
	    <span class="cont_tab_2015_txt_editor">Ahora se debate</span>
    </div>
    <div class="cont_int_secs_2015 cont_int_sec_pad_top_editor">
        <div class="cont_int_pad cont_int_sec_pad_side_editor">
            

            <div class="cont_secs_img_2015_editor not_ahora_editor">
                <div id="cuTodas_cuDebate_repDebate_contImg_0" class="cont_not_ahora_editor">
                    <a href="/noticias/Nacional/2017/12/03/885846/Solicitan-al-Gobierno-decretar-feriado-en-Santiago-por-visita-del-Papa.html#comentarios" id="cuTodas_cuDebate_repDebate_linkImg_0">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/03/file_20171203103814_0lx0.jpg" id="cuTodas_cuDebate_repDebate_Img_0" border="0" alt="¿Estás de acuerdo con decretar feriado en Santiago para la visita del Papa? La medida ya fue aprobada para Iquique y Temuco." />
                    </a>
                </div>

                <h5><a href="/noticias/Nacional/2017/12/03/885846/Solicitan-al-Gobierno-decretar-feriado-en-Santiago-por-visita-del-Papa.html#comentarios" id="cuTodas_cuDebate_repDebate_titulo_0">¿Estás de acuerdo con decretar feriado en Santiago para la visita del Papa? La medida ya fue aprobada para Iquique y Temuco.</a></h5>

                <div id="cuTodas_cuDebate_repDebate_ContadorComentarios_0" class="cont_contador_comentarios" data-id="885846">
                    <a href="/noticias/Nacional/2017/12/03/885846/Solicitan-al-Gobierno-decretar-feriado-en-Santiago-por-visita-del-Papa.html#comentarios" id="cuTodas_cuDebate_repDebate_LinkContadorComentarios_0">
                        <span class="fb_comments_count"></span>
                    </a>
                </div>
            </div>
            

            <div class="cont_secs_img_2015_editor not_ahora_editor">
                <div id="cuTodas_cuDebate_repDebate_contImg_1" class="cont_not_ahora_editor">
                    <a href="/noticias/Espectaculos/2017/12/02/885790/Levantate-mamita-El-nuevo-jingle-de-la-Teleton-que-genera-debate-entre-televidentes.html#comentarios" id="cuTodas_cuDebate_repDebate_linkImg_1">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/02/file_20171202115111_0lx0.jpg" id="cuTodas_cuDebate_repDebate_Img_1" border="0" alt="&amp;#34;Levántate mamita&amp;#34;. ¿Qué te pareció el nuevo jingle de la Teletón que generó discusión entre los televidentes?" />
                    </a>
                </div>

                <h5><a href="/noticias/Espectaculos/2017/12/02/885790/Levantate-mamita-El-nuevo-jingle-de-la-Teleton-que-genera-debate-entre-televidentes.html#comentarios" id="cuTodas_cuDebate_repDebate_titulo_1">&#34;Levántate mamita&#34;. ¿Qué te pareció el nuevo jingle de la Teletón que generó discusión entre los televidentes?</a></h5>

                <div id="cuTodas_cuDebate_repDebate_ContadorComentarios_1" class="cont_contador_comentarios" data-id="885790">
                    <a href="/noticias/Espectaculos/2017/12/02/885790/Levantate-mamita-El-nuevo-jingle-de-la-Teleton-que-genera-debate-entre-televidentes.html#comentarios" id="cuTodas_cuDebate_repDebate_LinkContadorComentarios_1">
                        <span class="fb_comments_count"></span>
                    </a>
                </div>
            </div>
            
        </div>
    </div>
</div>
        <div id="cuTodas_cuMasvistas_contMV" class="cont_tab_2015 cont_n_mas_vis_emol">
	<div class="cont_tab_2015_tit">
		<span class="cont_tab_2015_txt">noticias más vistas</span>
	</div>
	<div class="cont_int_secs_2015 cont_int_sec_pad_top">
		<div class="cont_int_pad cont_int_sec_pad_side">
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_0" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Espectaculos/2017/12/03/885836/Teleton-2017-sobrepasa-la-meta-pasadas-las-27-horas-de-amor.html" id="cuTodas_cuMasvistas_repMV_linkImg_0">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/03/file_20171203012352_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_0" alt="Teletón 2017 sobrepasa la meta pasadas las &quot;27 horas de amor&quot;" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_0" class="cont_contador_comentarios comentario_minimizado" data-id="885836">
                        <a href="/noticias/Espectaculos/2017/12/03/885836/Teleton-2017-sobrepasa-la-meta-pasadas-las-27-horas-de-amor.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_0">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_0" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Espectaculos/2017/12/03/885836/Teleton-2017-sobrepasa-la-meta-pasadas-las-27-horas-de-amor.html" id="cuTodas_cuMasvistas_repMV_titulo_0">Teletón 2017 sobrepasa la meta pasadas las "27 horas de amor"</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_1" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Espectaculos/2017/12/02/885827/En-tiempo-real-Teleton-se-prepara-para-el-cierre-de-su-ultima-edicion.html" id="cuTodas_cuMasvistas_repMV_linkImg_1">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/03/file_20171203093115_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_1" alt="¡Se logró la meta!: Revive el tiempo real del cierre de la Teletón 2017" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_1" class="cont_contador_comentarios comentario_minimizado" data-id="885827">
                        <a href="/noticias/Espectaculos/2017/12/02/885827/En-tiempo-real-Teleton-se-prepara-para-el-cierre-de-su-ultima-edicion.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_1">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_1" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Espectaculos/2017/12/02/885827/En-tiempo-real-Teleton-se-prepara-para-el-cierre-de-su-ultima-edicion.html" id="cuTodas_cuMasvistas_repMV_titulo_1">¡Se logró la meta!: Revive el tiempo real del cierre de la Teletón 2017</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_2" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Espectaculos/2017/12/02/885790/Levantate-mamita-El-nuevo-jingle-de-la-Teleton-que-genera-debate-entre-televidentes.html" id="cuTodas_cuMasvistas_repMV_linkImg_2">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/02/file_20171202115111_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_2" alt="&quot;Levántate mamita&quot;: El nuevo jingle de la Teletón que genera debate entre televidentes" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_2" class="cont_contador_comentarios comentario_minimizado" data-id="885790">
                        <a href="/noticias/Espectaculos/2017/12/02/885790/Levantate-mamita-El-nuevo-jingle-de-la-Teleton-que-genera-debate-entre-televidentes.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_2">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_2" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Espectaculos/2017/12/02/885790/Levantate-mamita-El-nuevo-jingle-de-la-Teleton-que-genera-debate-entre-televidentes.html" id="cuTodas_cuMasvistas_repMV_titulo_2">"Levántate mamita": El nuevo jingle de la Teletón que genera debate entre televidentes</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_3" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Deportes/2017/12/02/885807/El-comentario-del-DT-de-Dinamarca-que-genero-escandalo-en-Peru-y-por-el-que-acusan-ninguneo-tras-sorteo.html" id="cuTodas_cuMasvistas_repMV_linkImg_3">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/02/file_20171202152812_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_3" alt="El comentario del DT de Dinamarca que generó escándalo en Perú y por el que acusan ninguneo tras sorteo del Mundial" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_3" class="cont_contador_comentarios comentario_minimizado" data-id="885807">
                        <a href="/noticias/Deportes/2017/12/02/885807/El-comentario-del-DT-de-Dinamarca-que-genero-escandalo-en-Peru-y-por-el-que-acusan-ninguneo-tras-sorteo.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_3">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_3" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Deportes/2017/12/02/885807/El-comentario-del-DT-de-Dinamarca-que-genero-escandalo-en-Peru-y-por-el-que-acusan-ninguneo-tras-sorteo.html" id="cuTodas_cuMasvistas_repMV_titulo_3">El comentario del DT de Dinamarca que generó escándalo en Perú y por el que acusan ninguneo tras sorteo del Mundial</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_4" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Deportes/2017/12/02/885824/Recuerda-como-Colo-Colo-puede-ser-campeon-hoy-y-mira-a-que-hora-se-disputaran-los-duelos-clave.html" id="cuTodas_cuMasvistas_repMV_linkImg_4">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/02/file_20171202211942_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_4" alt="Colo Colo puede ser campeón hoy: Mira cómo y a qué hora se juegan las tres infartantes finales" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_4" class="cont_contador_comentarios comentario_minimizado" data-id="885824">
                        <a href="/noticias/Deportes/2017/12/02/885824/Recuerda-como-Colo-Colo-puede-ser-campeon-hoy-y-mira-a-que-hora-se-disputaran-los-duelos-clave.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_4">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_4" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Deportes/2017/12/02/885824/Recuerda-como-Colo-Colo-puede-ser-campeon-hoy-y-mira-a-que-hora-se-disputaran-los-duelos-clave.html" id="cuTodas_cuMasvistas_repMV_titulo_4">Colo Colo puede ser campeón hoy: Mira cómo y a qué hora se juegan las tres infartantes finales</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_5" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Nacional/2017/12/02/885831/Carabineros-confirma-detencion-del-jefe-de-Extranjeria-de-la-PDI-en-Antofagasta-por-conducir-en-estado-de-ebriedad.html" id="cuTodas_cuMasvistas_repMV_linkImg_5">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/02/file_20171202234519_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_5" alt="Carabineros detiene a jefe de Extranjería de la PDI en Antofagasta por conducir en estado de ebriedad" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_5" class="cont_contador_comentarios comentario_minimizado" data-id="885831">
                        <a href="/noticias/Nacional/2017/12/02/885831/Carabineros-confirma-detencion-del-jefe-de-Extranjeria-de-la-PDI-en-Antofagasta-por-conducir-en-estado-de-ebriedad.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_5">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_5" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Nacional/2017/12/02/885831/Carabineros-confirma-detencion-del-jefe-de-Extranjeria-de-la-PDI-en-Antofagasta-por-conducir-en-estado-de-ebriedad.html" id="cuTodas_cuMasvistas_repMV_titulo_5">Carabineros detiene a jefe de Extranjería de la PDI en Antofagasta por conducir en estado de ebriedad</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_6" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Espectaculos/2017/12/03/885851/Presidente-del-sindicato-de-TVN-deja-su-cargo.html" id="cuTodas_cuMasvistas_repMV_linkImg_6">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/03/file_20171203115253_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_6" alt="Llegada de Cony Stipicic a TVN genera la renuncia del presidente del sindicato de prensa del canal" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_6" class="cont_contador_comentarios comentario_minimizado" data-id="885851">
                        <a href="/noticias/Espectaculos/2017/12/03/885851/Presidente-del-sindicato-de-TVN-deja-su-cargo.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_6">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_6" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Espectaculos/2017/12/03/885851/Presidente-del-sindicato-de-TVN-deja-su-cargo.html" id="cuTodas_cuMasvistas_repMV_titulo_6">Llegada de Cony Stipicic a TVN genera la renuncia del presidente del sindicato de prensa del canal</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_7" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Deportes/2017/12/03/885843/DT-del-Bayern-duro-contra-Sampaoli-por-su-ninguneo-a-Alemania-No-se-si-bebio-vino-antes-de-hablar.html" id="cuTodas_cuMasvistas_repMV_linkImg_7">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/03/file_20171203092030_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_7" alt="DT del Bayern duro contra Sampaoli por su ninguneo a Alemania: &quot;No sé si bebió vino antes de hablar&quot;" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_7" class="cont_contador_comentarios comentario_minimizado" data-id="885843">
                        <a href="/noticias/Deportes/2017/12/03/885843/DT-del-Bayern-duro-contra-Sampaoli-por-su-ninguneo-a-Alemania-No-se-si-bebio-vino-antes-de-hablar.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_7">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_7" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Deportes/2017/12/03/885843/DT-del-Bayern-duro-contra-Sampaoli-por-su-ninguneo-a-Alemania-No-se-si-bebio-vino-antes-de-hablar.html" id="cuTodas_cuMasvistas_repMV_titulo_7">DT del Bayern duro contra Sampaoli por su ninguneo a Alemania: "No sé si bebió vino antes de hablar"</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_8" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Espectaculos/2017/12/02/885772/Ex-integrantes-de-Mekano-y-ex-chica-reality-se-coronaron-como-los-ganadores-de-los-Triangulos-de-Fuego.html" id="cuTodas_cuMasvistas_repMV_linkImg_8">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/02/file_20171202074835_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_8" alt="Ex integrantes de &quot;Mekano&quot; y ex chica reality se coronaron como los ganadores de la otrora &quot;Vedetón&quot;" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_8" class="cont_contador_comentarios comentario_minimizado" data-id="885772">
                        <a href="/noticias/Espectaculos/2017/12/02/885772/Ex-integrantes-de-Mekano-y-ex-chica-reality-se-coronaron-como-los-ganadores-de-los-Triangulos-de-Fuego.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_8">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_8" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Espectaculos/2017/12/02/885772/Ex-integrantes-de-Mekano-y-ex-chica-reality-se-coronaron-como-los-ganadores-de-los-Triangulos-de-Fuego.html" id="cuTodas_cuMasvistas_repMV_titulo_8">Ex integrantes de "Mekano" y ex chica reality se coronaron como los ganadores de la otrora "Vedetón"</a>                    
                </div>                
            </div>
            
            <div id="cuTodas_cuMasvistas_repMV_contCaja_9" class="caja_contenedor_masvistos_modulo">
                <div class="caja_contenedor_masvistos_modulo_foto">
                    <a href="/noticias/Espectaculos/2017/12/02/885830/Homenaje-a-Luis-Maria-Bonini-abre-la-noche-final-de-la-Teleton-El-ex-preparador-fisico-de-la-seleccion-tuvo-un-estrecho-vinculo-con-la-fundacion.html" id="cuTodas_cuMasvistas_repMV_linkImg_9">
                        <img src="http://static.emol.cl/emol50/Fotos/2017/12/02/file_20171202220928_120x75.jpg" id="cuTodas_cuMasvistas_repMV_Img_9" alt="Homenaje a Luis María Bonini en la Teletón: El ex preparador físico de la Roja tuvo un vínculo con la fundación" border="0" />
                    </a>                                 
                </div>
                <div id="cuTodas_cuMasvistas_repMV_ContadorComentarios_9" class="cont_contador_comentarios comentario_minimizado" data-id="885830">
                        <a href="/noticias/Espectaculos/2017/12/02/885830/Homenaje-a-Luis-Maria-Bonini-abre-la-noche-final-de-la-Teleton-El-ex-preparador-fisico-de-la-seleccion-tuvo-un-estrecho-vinculo-con-la-fundacion.html#comentarios" id="cuTodas_cuMasvistas_repMV_LinkContadorComentarios_9">
                            <div class="cont_int_comment_more">                                
                                <span class="fb_comments_count"></span>    
                            </div>
                        </a>
                    </div>       
                <div class="caja_contenedor_masvistos_modulo_texto">
                    <span id="cuTodas_cuMasvistas_repMV_cont_9" class="caja_contenedor_masvistos_modulo_texto_color"></span>
                    <a href="/noticias/Espectaculos/2017/12/02/885830/Homenaje-a-Luis-Maria-Bonini-abre-la-noche-final-de-la-Teleton-El-ex-preparador-fisico-de-la-seleccion-tuvo-un-estrecho-vinculo-con-la-fundacion.html" id="cuTodas_cuMasvistas_repMV_titulo_9">Homenaje a Luis María Bonini en la Teletón: El ex preparador físico de la Roja tuvo un vínculo con la fundación</a>                    
                </div>                
            </div>
            
		</div>
	</div>
</div>
        
                     
    </div>
    
<div class="cont_footer_2015">
    <div id="contenedorFooterEmol">
        <div id="FooterEmol">
            <div id="LogoFooterEmol"><a href="http://www.emol.com/"><img src="http://static.emol.cl/emol50/img/logoEmolFooter16.png" alt="Emol.com" width="165" height="18" /></a></div>
            <div class="contenedorList-1-FooterEmol">
                <div class="ListFooterEmol">
                    <ul>
                        <li><a href="/">NOTICIAS</a></li>
                        <li><a href="/economia/">ECONOMÍA</a></li>
                        <li><a href="/deportes/">DEPORTES</a></li>
                        <li><a href="/espectaculos/">ESPECTÁCULOS</a></li>
                        <li><a href="/tecnologia/">TECNOLOGÍA</a></li>
                    </ul>
                </div>
            </div>
            <div class="contenedorList-1-FooterEmol">
                <div class="ListFooterEmol">
                    <ul>
                        <li><a href="/tendencias/" target="_blank">TENDENCIAS</a></li>
                        <li><a href="/servicios/">SERVICIOS</a></li>
                        <li><a href="http://tv.emol.com/">EMOL TV</a></li>
                        <li><a href="http://www.emol.com/fotos/">EMOL FOTOS</a></li>
                        <li><a href="http://restaurantes.emol.com/">EMOL RESTAURANTES</a></li>
                    </ul>
                </div>
            </div>
            <div class="contenedorList-3-FooterEmol">
                <div class="ListFooterEmol">
                    <ul>
                        <li><a href="http://automoviles.emol.com/">EMOL AUTOS</a></li>
                        <li><a href="http://www.propiedades.emol.com/">EMOL PROPIEDADES</a></li>
                        <li><a href="http://empleos.emol.com/">EMOL EMPLEOS</a></li>
                        <li><a href="/contacto/">CONTACTOS</a></li>
                        <li><a href="/sitemap/">MAPA DEL SITIO</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="FooterElmercurio">
            <div id="LogoFooterElmercurio"><a href="http://www.mer.cl/"><img src="http://static.emol.cl/emol50/img/logoElMercurioFooter16.png" alt="El Mercurio" width="165" height="18" /></a></div>
            <div class="contenedorList-2-FooterEmol">
                <div class="ListFooterEmol">
                    <ul>
                        <li><a href="http://www.clubdelectores.cl/">CLUB DE LECTORES</a></li>
                        <li><a href="/_portada/">EMOL.COM</a></li>
                        <li><a href="http://www.mer.cl/">EL MERCURIO</a></li>
                        <li><a href="http://www.elmercurio.com/blogs/">BLOGS</a></li>
                        <li><a href="http://www.elmercurio.com/legal/">LEGAL</a></li>
                    </ul>
                </div>
            </div>
            <div class="contenedorList-1-FooterEmol">
                <div class="ListFooterEmol">
                    <ul>
                        <li><a href="http://www.elmercurio.com/campo/">CAMPO</a></li>
                        <li><a href="http://www.elmercurio.com/inversiones/">INVERSIONES</a></li>
                        <li><a href="http://www.lun.com/">LUN</a></li>
                        <li><a href="http://www.lasegunda.com/">LA SEGUNDA</a></li>
                        <li><a href="http://www.soychile.cl/">SOYCHILE.CL</a></li>
                    </ul>
                </div>
            </div>
            <div class="contenedorList-3-FooterEmol">
                <div class="ListFooterEmol">
                    <ul>
                        <li><a href="http://www.economicos.cl/">ECONÓMICOS.CL</a></li>
                        <li><a href="http://www.adxion.com/">ADXION</a></li>
                        <li><a href="http://www.valorfuturo.com/">VALOR FUTURO</a></li>
                        <li><a href="http://www.farox.com/">FAROX</a></li>
                        <li><a href="http://www.vivedescuentos.com/">VIVEDESCUENTOS</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="FooterTerminos"> 
          <p>
            <a href="/Terminos/DerechosdeAutor.aspx">Derechos de Autor</a> | 
	        <a href="/Terminos/Terminosycondiciones.aspx">Términos y Condiciones de los Servicios ® 2011 Empresa El Mercurio S.A.P.</a>
          </p>
        </div>
    </div>
</div>
<script>function utmx_section() { } function utmx() { } (function () {
var
k = '17931989-2', d = document, l = d.location, c = d.cookie;
    if (l.search.indexOf('utm_expid=' + k) > 0) return;
    function f(n) {
        if (c) {
            var i = c.indexOf(n + '='); if (i > -1) {
                var j = c.
                indexOf(';', i); return escape(c.substring(i + n.length + 1, j < 0 ? c.
                    length : j))
            }
        }
    } var x = f('__utmx'), xx = f('__utmxx'), h = l.hash; d.write(
    '<sc' + 'ript src="' + 'http' + (l.protocol == 'https:' ? 's://ssl' :
    '://www') + '.google-analytics.com/ga_exp.js?' + 'utmxkey=' + k +
    '&utmx=' + (x ? x : '') + '&utmxx=' + (xx ? xx : '') + '&utmxtime=' + new Date().
    valueOf() + (h ? '&utmxhash=' + escape(h.substr(1)) : '') +
    '" type="text/javascript" charset="utf-8"><\/sc' + 'ript>')
})();
</script><script>    utmx('url', 'A/B');</script>
<script type="text/javascript" src="http://static.emol.cl/emol50/js/marcacionUniversal.js?v=2"></script>
<script type="text/javascript">registraGA("0", "/todas/");</script>
<script type="text/javascript">setTimeout(MarcaPiwik("0", "/todas/"), 2000);</script>
<noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=3Focj1a4ZP00Uw" style="display:none" height="1" width="1" alt="" /></noscript>
<script type="text/javascript">
//alexa
_atrk_opts = { atrk_acct: "3Focj1a4ZP00Uw", domain: "emol.com", dynamic: true };
(function () { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(as, s); })();
</script>
<noscript><p><img src="//analytics.emol.ecn.cl/piwik.php?idsite=1" style="border:0;" alt="" /></p></noscript>
<script type='text/javascript'>
    <!--// <![CDATA[ 
    if (typeof (zn) != 'undefined' && typeof (pl) != 'undefined' && typeof (dm) != 'undefined' && typeof (az) != 'undefined' && az == true) { if (typeof (qString) == 'undefined') { var qString = ''; var qStringl = ''; var rString = ''; for (var i = 5; i > 0; --i) qString += 'abcdefghijklmnopqrstuvwxyz'[Math.round(Math.random() * ('abcdefghijklmnopqrstuvwxyz'.length - 1))]; for (var i = 2; i > 0; --i) qStringl += '0123456789'[Math.round(Math.random() * ('0123456789'.length - 1))]; for (var i = 10; i > 0; --i) rString += '0123456789abcdefghijklmnopqrstuvwxyz'[Math.round(Math.random() * ('0123456789abcdefghijklmnopqrstuvwxyz'.length - 1))]; qString = qString + "=" + qStringl; } $.get('http://rvv.emol.com/www/noticias/sqm.php?' + qString + '&bannerid=' + dm.join("|") + '&campaignid=' + pl.join("|") + '&zoneid=' + zn.join("|") + '&loc=' + document.location + '&cb=' + rString); }
    // ]]> -->
</script>



<script type="text/javascript" src="http://static.emol.cl/emol50/js/rt_tag.ofs.js"></script>

<!-- Publicidad El Mercurio -->

    <div id="scroll_1" class="scroll">
        <div id="scroll-inner1" class="scrolling1">
            <script type='text/javascript'>
            <!--// <![CDATA[
                OA_show('NO_300X560');
            // ]]> -->
            </script>
        </div>
    </div>
    <div id="scroll_2" class="scroll">
        <div id="scroll-inner2" >
            <script type='text/javascript'>
            <!--// <![CDATA[
                OA_show('NO_300X250_ADX');
            // ]]> -->
            </script>
        </div>
    </div>
</body>
</html>